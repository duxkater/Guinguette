"use strict";
const { Plugin, MarkdownView } = require("obsidian");

const PRELOAD_COUNT = 3;

class BannerView {
  constructor(app, plugin) {
    this.app = app;
    this.plugin = plugin;
    this.leaf = null;
    this.wrapper = null;
    this.setupLeafPromise = null;
    this._currentFile = null; // Garde trace du fichier actuellement affiché
  }

  setup() {
    this.leaf = this.app.workspace.getLeaf("tab");
    this.setupLeafPromise = this._initLeaf();

    const viewContent = this.leaf.view.containerEl.querySelector(".view-content");

    const inner = document.createElement("div");
    inner.classList.add("graph-banner-bottom-inner");
    inner.appendChild(viewContent);

    this.wrapper = document.createElement("div");
    this.wrapper.classList.add("graph-banner-bottom-content");
    this.wrapper.style.setProperty("margin-top", "-450px", "important");
    this.wrapper.appendChild(inner);
  }

  _getEngineOpts() {
    const extGraph = this.app.plugins?.plugins?.["extended-graph"];
    return extGraph?.settings?.states?.[0]?.engineOptions ?? {};
  }

  async _initLeaf() {
    const opts = this._getEngineOpts();
    await this.leaf.setViewState({
      type: "localgraph",
      state: {
        colorGroups:        opts.colorGroups        ?? [],
        hideUnresolved:     opts.hideUnresolved      ?? false,
        showAttachments:    opts.showAttachments     ?? false,
        showTags:           opts.showTags            ?? false,
        showArrow:          opts.showArrow           ?? false,
        textFadeMultiplier: opts.textFadeMultiplier  ?? 0,
        nodeSizeMultiplier: opts.nodeSizeMultiplier  ?? 1,
        lineSizeMultiplier: opts.lineSizeMultiplier  ?? 1,
        centerStrength:     opts.centerStrength      ?? 0.518,
        repelStrength:      opts.repelStrength       ?? 10,
        linkStrength:       opts.linkStrength        ?? 1,
        linkDistance:       opts.linkDistance        ?? 250,
        localJumps:         1,
        localBacklinks:     true,
        localForelinks:     true,
        localInterlinks:    false,
      },
    });
    const delay = this.plugin.settings.timeToRemoveLeaf;
    await new Promise(resolve => {
      setTimeout(() => {
        try {
          if (this.leaf && this.leaf.parent) this.leaf.parent.removeChild(this.leaf);
        } catch (e) {}
        resolve();
      }, delay);
    });
  }

  async placeTo(mdView) {
    await this.setupLeafPromise;

    const alreadyPlaced = this.isDescendantOf(mdView.contentEl);
    const sameFile = this._currentFile === mdView.file.path;

    // ✅ FIX PRINCIPAL : on ne touche à rien si la bannière est déjà en place
    // avec le bon fichier. Casse la boucle layout-change → setViewState → layout-change.
    if (alreadyPlaced && sameFile) return;

    // Mise à jour du fichier courant AVANT setViewState pour éviter
    // toute ré-entrée concurrente (layout-change qui arriverait pendant l'await).
    this._currentFile = mdView.file.path;

    try {
      await this.leaf.setViewState({
        type: "localgraph",
        state: { file: mdView.file.path },
      });
      if (this.leaf.setGroup) this.leaf.setGroup(mdView.file.path);
    } catch (e) {}

    // Si la bannière est déjà dans le DOM de cette note, pas besoin de ré-appender.
    if (alreadyPlaced) return;

    const mode = mdView.getMode();
    let container;
    if (mode === "source" || mode === "live") {
      container = mdView.contentEl.querySelector(".cm-sizer");
    } else {
      container = mdView.contentEl.querySelector(".markdown-preview-sizer");
    }
    if (!container) return;

    container.appendChild(this.wrapper);
  }

  isDescendantOf(el) {
    return el.contains(this.wrapper);
  }

  detach() {
    try { this.leaf.detach(); } catch (e) {}
    if (this.wrapper) this.wrapper.remove();
  }
}

class GraphBannerBottomPlugin extends Plugin {
  async onload() {
    this.settings = { timeToRemoveLeaf: 500 };
    this.bannerViews = [];
    this._layoutChangeTimer = null; // Pour le debounce

    this.app.workspace.onLayoutReady(async () => {
      await this._preload(PRELOAD_COUNT);
      const view = this.app.workspace.getActiveViewOfType(MarkdownView);
      if (view) await this.placeGraphView(view);
    });

    this.registerEvent(
      this.app.workspace.on("file-open", async (file) => {
        if (!file || file.extension !== "md") return;
        const view = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (view && view.file === file) await this.placeGraphView(view);
      })
    );

    // ✅ FIX SECONDAIRE : debounce sur layout-change pour éviter les appels
    // en rafale (l'appendChild lui-même déclenche layout-change).
    this.registerEvent(
      this.app.workspace.on("layout-change", () => {
        clearTimeout(this._layoutChangeTimer);
        this._layoutChangeTimer = setTimeout(async () => {
          const view = this.app.workspace.getActiveViewOfType(MarkdownView);
          if (view) await this.placeGraphView(view);
        }, 150);
      })
    );
  }

  async _preload(count) {
    const banners = [];
    for (let i = 0; i < count; i++) {
      const b = new BannerView(this.app, this);
      b.setup();
      banners.push(b);
    }
    await Promise.all(banners.map(b => b.setupLeafPromise));
    this.bannerViews.push(...banners);
  }

  onunload() {
    clearTimeout(this._layoutChangeTimer);
    for (const banner of this.bannerViews) banner.detach();
    this.bannerViews = [];
  }

  async placeGraphView(mdView) {
    const banner = await this.findAvailableBanner(mdView);
    await banner.placeTo(mdView);
  }

  async findAvailableBanner(mdView) {
    // 1. Déjà une bannière dans ce container ?
    const existing = this.bannerViews.find(b => b.isDescendantOf(mdView.contentEl));
    if (existing) return existing;

    // 2. Une bannière libre (pas dans une note ouverte) ?
    const openContents = this.app.workspace
      .getLeavesOfType("markdown")
      .map(l => l.view.contentEl);
    const free = this.bannerViews.find(b => !openContents.some(c => b.isDescendantOf(c)));
    if (free) return free;

    // 3. Créer une nouvelle bannière (cas rare : plus de tabs que PRELOAD_COUNT)
    const banner = new BannerView(this.app, this);
    banner.setup();
    this.bannerViews.push(banner);
    await banner.setupLeafPromise;
    return banner;
  }
}

module.exports = GraphBannerBottomPlugin;
